import os
import sqlite3
import csv
import logging
from datetime import datetime
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
    ConversationHandler,
)

# Load environment variables
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_CHAT_ID = int(os.getenv("ADMIN_CHAT_ID", "0"))

# Logging setup
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# Database Initialization
def init_db():
    conn = sqlite3.connect("registrations.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            full_name TEXT,
            phone TEXT,
            address TEXT,
            students TEXT,
            schedule TEXT,
            status TEXT,
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()

init_db()

# Conversation States
FULL_NAME, PHONE, ADDRESS, NUM_CHILDREN, STUDENT_DETAILS, SCHEDULE_SELECTION, PAYMENT_UPLOAD = range(7)

# Persistent Reply Keyboards
main_menu_keyboard = [
    ["🚀 ምዝገባ ጀምር (Start Registration)", "ℹ️ ስለ እኛ (About Us)"],
    ["❌ ምዝገባ ሰርዝ (Cancel)"]
]

# 1. Start Command
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_name = update.effective_user.first_name
    context.user_data.clear()
    
    reply_markup = ReplyKeyboardMarkup(main_menu_keyboard, resize_keyboard=True)
    
    welcome_text = (
        f"👋 ሰላም <b>{user_name}</b>!\n\n"
        "እንኳን ወደ ኦፊሴላዊው የትምህርት ማዕከል <b>Ultra Registration Bot</b> በደህና መጡ። 🎓\n\n"
        "ምዝገባ ለመጀመር ከታች ያለውን ቁልፍ ይጫኑ፡"
    )
    await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode="HTML")
    return ConversationHandler.END

# Handle Text Menu Options outside flow
async def handle_menu_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text
    if "ምዝገባ ጀምር" in text:
        return await start_registration(update, context)
    elif "ስለ እኛ" in text:
        await update.message.reply_text(
            "🏫 <b>ስለ ትምህርት ማዕከላችን:</b>\n\n"
            "ማዕከላችን ጥራት ያለው ዘመናዊ ትምህርት ለልጆች ይሰጣል።\n"
            "ስልክ: 0911223344\n"
            "አድራሻ: አዲስ አበባ፣ ኢትዮጵያ",
            parse_mode="HTML"
        )
        return ConversationHandler.END
    elif "ሰርዝ" in text:
        return await cancel(update, context)
    else:
        await update.message.reply_text("⚠️ እባክዎ ከታች ያሉትን ቁልፎች ይጠቀሙ ወይም /start ይጫኑ።")
        return ConversationHandler.END

# Actual Registration Entry Point
async def start_registration(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    reply_markup = ReplyKeyboardMarkup([["❌ ምዝገባ ሰርዝ (Cancel)"]], resize_keyboard=True)
    await update.message.reply_text(
        "እባክዎ ለመጀመር የወላጅ/አሳዳጊ <b>ሙሉ ስምዎን</b> ያስገቡ፡",
        reply_markup=reply_markup,
        parse_mode="HTML"
    )
    return FULL_NAME

# 2. Parent Name
async def get_full_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if "ሰርዝ" in update.message.text:
        return await cancel(update, context)
        
    context.user_data["full_name"] = update.message.text
    
    contact_button = [
        [KeyboardButton("📱 ስልክ ቁጥሬን አጋራ (Share Contact)", request_contact=True)],
        ["❌ ምዝገባ ሰርዝ (Cancel)"]
    ]
    reply_markup = ReplyKeyboardMarkup(contact_button, resize_keyboard=True, one_time_keyboard=True)
    
    await update.message.reply_text(
        "አመሰግናለሁ። እባክዎ ስልክ ቁጥርዎን ከታች ያለውን ቁልፍ በመጫን ወይም በመጻፍ ያጋሩን (ለምሳሌ፦ 0911223344)፡",
        reply_markup=reply_markup
    )
    return PHONE

# 3. Phone Number
async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.text and "ሰርዝ" in update.message.text:
        return await cancel(update, context)
        
    phone = update.message.contact.phone_number if update.message.contact else update.message.text
    context.user_data["phone"] = phone
    
    reply_markup = ReplyKeyboardMarkup([["❌ ምዝገባ ሰርዝ (Cancel)"]], resize_keyboard=True)
    await update.message.reply_text(
        "አመሰግናለሁ! 📍 አሁን ደግሞ የመኖሪያ አድራሻዎን (ከተማ እና ቀበሌ) ያስገቡ፡",
        reply_markup=reply_markup
    )
    return ADDRESS

# 4. Address
async def get_address(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if "ሰርዝ" in update.message.text:
        return await cancel(update, context)
        
    context.user_data["address"] = update.message.text
    await update.message.reply_text("የልጆችዎ ብዛት ስንት ነው? (ቁጥር ብቻ ያስገቡ፣ ለምሳሌ፦ 2)፡")
    return NUM_CHILDREN

# 5. Number of Children
async def get_num_children(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if "ሰርዝ" in update.message.text:
        return await cancel(update, context)
        
    try:
        num = int(update.message.text)
        if num <= 0:
            raise ValueError
        context.user_data["num_children"] = num
        context.user_data["current_child"] = 1
        context.user_data["students"] = []
        
        await update.message.reply_text(
            f"እባክዎ የልጅ #1 <b>ስም እና ክፍል</b> ያስገቡ (ለምሳሌ፦ ዳዊት - 5ኛ ክፍል):",
            parse_mode="HTML"
        )
        return STUDENT_DETAILS
    except ValueError:
        await update.message.reply_text("⚠️ እባክዎ ትክክለኛ የቁጥር እሴት (ከ 0 በላይ) ብቻ ያስገቡ።")
        return NUM_CHILDREN

# 6. Student Details Loop
async def get_student_details(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if "ሰርዝ" in update.message.text:
        return await cancel(update, context)
        
    student_info = update.message.text
    context.user_data["students"].append(student_info)
    
    current = context.user_data["current_child"]
    total = context.user_data["num_children"]
    
    if current < total:
        context.user_data["current_child"] += 1
        await update.message.reply_text(f"እባክዎ የልጅ #{context.user_data['current_child']} ስም እና ክፍል ያስገቡ:")
        return STUDENT_DETAILS
    else:
        summary = (
            f"📋 <b>የምዝገባ ማጠቃለያ:</b>\n\n"
            f"👤 <b>ወላጅ፦</b> {context.user_data['full_name']}\n"
            f"📞 <b>ስልክ፦</b> {context.user_data['phone']}\n"
            f"📍 <b>አድራሻ፦</b> {context.user_data['address']}\n"
            f"👨‍🎓 <b>ልጆች፦</b> {', '.join(context.user_data['students'])}\n\n"
            "━━━━━━━━━━━━━━━━━━━\n"
            "🕒 <b>እባክዎ የሚፈልጉትን የትምህርት ጊዜ ይምረጡ፡</b>"
        )
        
        keyboard = [
            [InlineKeyboardButton("📅 ቅዳሜ እና እሁድ (ጠዋት)", callback_data="sched_weekend_morning")],
            [InlineKeyboardButton("📅 ቅዳሜ እና እሁድ (ከሰዓት)", callback_data="sched_weekend_afternoon")],
            [InlineKeyboardButton("📅 ከሰኞ - አርብ (ከሰዓት በኋላ)", callback_data="sched_weekday")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(summary, reply_markup=reply_markup, parse_mode="HTML")
        return SCHEDULE_SELECTION

# 7. Schedule Selection Handler
async def schedule_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    
    choice = query.data
    schedule_map = {
        "sched_weekend_morning": "ቅዳሜ እና እሁድ (ጠዋት)",
        "sched_weekend_afternoon": "ቅዳሜ እና እሁድ (ከሰዓት)",
        "sched_weekday": "ከሰኞ - አርብ (ከሰዓት በኋላ)"
    }
    context.user_data["schedule"] = schedule_map.get(choice, "መደበኛ")
    
    payment_instructions = (
        f"✅ <b>መረጡት መርሃ-ግብር፦ {context.user_data['schedule']}</b>\n\n"
        "💳 <b>የክፍያ መመሪያ:</b>\n"
        "• <b>ንግድ ባንክ (CBE):</b> 1000123456789 (በአቢይ ስዩም)\n"
        "• <b>ቴሌብር (Telebirr):</b> 0911223344\n\n"
        "📸 ክፍያውን ከፈጸሙ በኋላ <b>የባንክ ማስተላለፊያ ደረሰኝ (Screenshot)</b> ፎቶ በዚህ ቦት ላይ ይላኩ።"
    )
    
    reply_markup = ReplyKeyboardMarkup([["❌ ምዝገባ ሰርዝ (Cancel)"]], resize_keyboard=True)
    await query.edit_message_text(text=payment_instructions, parse_mode="HTML")
    
    # Send a prompt message with cancel keyboard for the photo upload step
    await context.bot.send_message(chat_id=update.effective_chat.id, text="👇 እባክዎ የክፍያ ፎቶውን ይላኩ፡", reply_markup=reply_markup)
    return PAYMENT_UPLOAD

# 8. Payment Receipt & Database Save + Admin Alert
async def payment_received(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.text and "ሰርዝ" in update.message.text:
        return await cancel(update, context)
        
    user = update.effective_user
    
    if not update.message.photo:
        await update.message.reply_text("⚠️ እባክዎ የክፍያውን ማስተላለፊያ ደረሰኝ (Screenshot) ፎቶ ብቻ ይላኩ።")
        return PAYMENT_UPLOAD

    file_id = update.message.photo[-1].file_id
    students_str = ", ".join(context.user_data["students"])
    
    # Save to SQLite Database
    conn = sqlite3.connect("registrations.db")
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO registrations (user_id, full_name, phone, address, students, schedule, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        user.id,
        context.user_data["full_name"],
        context.user_data["phone"],
        context.user_data["address"],
        students_str,
        context.user_data["schedule"],
        "Pending",
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))
    conn.commit()
    conn.close()

    # Build report for admin
    parent_summary = (
        f"🔔 <b>አዲስ የምዝገባ እና የክፍያ ጥያቄ!</b>\n\n"
        f"👤 <b>ወላጅ፦</b> {context.user_data['full_name']}\n"
        f"📞 <b>ስልክ፦</b> {context.user_data['phone']}\n"
        f"📍 <b>አድራሻ፦</b> {context.user_data['address']}\n"
        f"👨‍🎓 <b>ልጆች፦</b> {students_str}\n"
        f"🕒 <b>መርሃ-ግብር፦</b> {context.user_data['schedule']}\n"
        f"💬 <b>Telegram User ID:</b> <code>{user.id}</code>"
    )

    keyboard = [
        [
            InlineKeyboardButton("✅ አረጋግጥ (Approve)", callback_data=f"approve_{user.id}"),
            InlineKeyboardButton("❌ ውድቅ አድርግ (Reject)", callback_data=f"reject_{user.id}")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    try:
        await context.bot.send_photo(
            chat_id=ADMIN_CHAT_ID,
            photo=file_id,
            caption=parent_summary,
            reply_markup=reply_markup,
            parse_mode="HTML"
        )
    except Exception as e:
        logger.error(f"Failed to send to admin: {e}")

    main_menu_markup = ReplyKeyboardMarkup(main_menu_keyboard, resize_keyboard=True)
    await update.message.reply_text(
        "⏳ <b>ክፍያዎ ደርሷል!</b>\n\n"
        "አስተዳዳሪው መረጃዎን አጣርቶ በቅርቡ ማረጋገጫ ይልክልዎታል። እናመሰግናለን!",
        reply_markup=main_menu_markup,
        parse_mode="HTML"
    )
    return ConversationHandler.END

# 9. Admin Action Handler (Approve / Reject)
async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    
    data = query.data
    parts = data.split("_")
    action = parts[0]
    target_user_id = int(parts[1])
    
    conn = sqlite3.connect("registrations.db")
    cursor = conn.cursor()
    
    if action == "approve":
        cursor.execute("UPDATE registrations SET status = 'Approved' WHERE user_id = ?", (target_user_id,))
        conn.commit()
        
        try:
            success_msg = (
                "🎉 <b>እንኳን ደስ አለዎት! ምዝገባዎ ጸድቋል።</b>\n\n"
                "ትምህርቱ የሚጀምርበት ቀን እና ዝርዝር መረጃ በቅርቡ ይላክልዎታል።"
            )
            await context.bot.send_message(chat_id=target_user_id, text=success_msg, parse_mode="HTML")
        except Exception as e:
            logger.error(f"Could not message user: {e}")
            
        await query.edit_message_caption(
            caption=query.message.caption + "\n\n<b>[✅ ሁኔታ፦ ጸድቋል / Approved]</b>",
            parse_mode="HTML"
        )
    elif action == "reject":
        cursor.execute("UPDATE registrations SET status = 'Rejected' WHERE user_id = ?", (target_user_id,))
        conn.commit()
        
        try:
            reject_msg = "❌ <b>የምዝገባ ጥያቄዎ ውድቅ ተደርጓል።</b> እባክዎ ማዕከላችንን ያነጋግሩ።"
            await context.bot.send_message(chat_id=target_user_id, text=reject_msg, parse_mode="HTML")
        except Exception as e:
            logger.error(f"Could not message user: {e}")
            
        await query.edit_message_caption(
            caption=query.message.caption + "\n\n<b>[❌ ሁኔታ፦ ውድቅ ተደርጓል / Rejected]</b>",
            parse_mode="HTML"
        )
    conn.close()

# 10. Admin Command: Export CSV (`/export`)
async def export_data(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("⛔ ይህን ትዕዛዝ መጠቀም የሚችሉት አስተዳዳሪዎች ብቻ ናቸው።")
        return

    conn = sqlite3.connect("registrations.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, full_name, phone, address, students, schedule, status, created_at FROM registrations")
    rows = cursor.fetchall()
    conn.close()

    filename = "registrations_report.csv"
    with open(filename, mode="w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Full Name", "Phone", "Address", "Students", "Schedule", "Status", "Date"])
        writer.writerows(rows)

    with open(filename, mode="rb") as f:
        await update.message.reply_document(
            document=f,
            filename="registrations_report.csv",
            caption="📊 <b>የሁሉም ተመዝጋቢዎች ሪፖርት (CSV)</b>",
            parse_mode="HTML"
        )

# 11. Admin Command: Stats (`/stats`)
async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if user_id != ADMIN_CHAT_ID:
        return

    conn = sqlite3.connect("registrations.db")
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM registrations")
    total = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM registrations WHERE status='Approved'")
    approved = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM registrations WHERE status='Pending'")
    pending = cursor.fetchone()[0]
    conn.close()

    stats_text = (
        f"📈 <b>የምዝገባ ስታቲስቲክስ (Admin Dashboard)</b>\n\n"
        f"• ጠቅላላ ተመዝጋቢዎች፦ <b>{total}</b>\n"
        f"• የጸደቁ (Approved)፦ <b>{approved}</b>\n"
        f"• በመጠባበቅ ላይ (Pending)፦ <b>{pending}</b>"
    )
    await update.message.reply_text(stats_text, parse_mode="HTML")

# Cancel command
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    reply_markup = ReplyKeyboardMarkup(main_menu_keyboard, resize_keyboard=True)
    await update.message.reply_text("ምዝገባው ተሰርዟል። ወደ ዋናው ማውጫ ተመልሰናል።", reply_markup=reply_markup)
    return ConversationHandler.END

def main() -> None:
    application = Application.builder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler("start", start),
            MessageHandler(filters.Regex("^🚀 ምዝገባ ጀምር"), start_registration)
        ],
        states={
            FULL_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_full_name)],
            PHONE: [MessageHandler(filters.TEXT | filters.CONTACT & ~filters.COMMAND, get_phone)],
            ADDRESS: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_address)],
            NUM_CHILDREN: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_num_children)],
            STUDENT_DETAILS: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_student_details)],
            SCHEDULE_SELECTION: [CallbackQueryHandler(schedule_selected, pattern="^sched_")],
            PAYMENT_UPLOAD: [MessageHandler(filters.PHOTO | filters.TEXT, payment_received)],
        },
        fallbacks=[
            CommandHandler("cancel", cancel),
            MessageHandler(filters.Regex("ሰርዝ"), cancel)
        ],
        per_message=True,
    )

    application.add_handler(conv_handler)
    application.add_handler(CommandHandler("export", export_data))
    application.add_handler(CommandHandler("stats", admin_stats))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_menu_text))
    application.add_handler(CallbackQueryHandler(admin_callback, pattern="^(approve|reject)_"))

    print("🚀 Ultra-Advanced Enterprise Telegram Bot is running live...")
    application.run_polling()

if __name__ == "__main__":
    main()