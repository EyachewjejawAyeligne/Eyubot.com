import time
from collections import defaultdict, deque
from functools import wraps
from config import config

_user_hits: dict[int, deque] = defaultdict(lambda: deque(maxlen=config.MAX_MESSAGES_PER_MIN))
_last_msg: dict[int, float] = {}


def rate_limited(func):
    @wraps(func)
    async def wrapper(update, context, *a, **kw):
        uid = update.effective_user.id
        now = time.time()
        if now - _last_msg.get(uid, 0) < config.RATE_LIMIT_SECONDS:
            return None
        _last_msg[uid] = now
        hits = _user_hits[uid]
        hits.append(now)
        if len(hits) == hits.maxlen and now - hits[0] < 60:
            try:
                await update.effective_message.reply_text(
                    "⏳ በጣም ብዙ ጥያቄዎች። እባክዎ ትንሽ ቆይተው ይሞክሩ።"
                )
            except Exception:
                pass
            return None
        return await func(update, context, *a, **kw)
    return wrapper


def admin_only(func):
    @wraps(func)
    async def wrapper(update, context, *a, **kw):
        if update.effective_user.id not in config.ADMIN_IDS:
            msg = update.effective_message
            if msg:
                await msg.reply_text("⛔ ይህ ትዕዛዝ ለአስተዳዳሪዎች ብቻ ነው።")
            return None
        return await func(update, context, *a, **kw)
    return wrapper