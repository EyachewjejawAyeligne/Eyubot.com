import asyncio, json, logging
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import Any
import aiosqlite
from config import config

logger = logging.getLogger(__name__)

SCHEMA = """
PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS registrations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 username TEXT,
 full_name TEXT NOT NULL,
 phone TEXT NOT NULL,
 address TEXT NOT NULL,
 students TEXT NOT NULL,
 grade TEXT,
 schedule TEXT NOT NULL,
 price INTEGER,
 hours_per_day TEXT,
 payment_plan TEXT,
 status TEXT NOT NULL DEFAULT 'Pending',
 receipt_file TEXT,
 transaction_id TEXT,
 reject_reason TEXT,
 admin_notes TEXT,
 approved_at TEXT,
 next_payment_due TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL);

CREATE INDEX IF NOT EXISTS idx_reg_user    ON registrations(user_id);
CREATE INDEX IF NOT EXISTS idx_reg_status  ON registrations(status);
CREATE INDEX IF NOT EXISTS idx_reg_due     ON registrations(next_payment_due);

CREATE TABLE IF NOT EXISTS book_orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 username TEXT,
 full_name TEXT,
 phone TEXT,
 order_type TEXT NOT NULL,
 category TEXT,
 amount INTEGER,
 status TEXT NOT NULL DEFAULT 'Pending',
 receipt_file TEXT,
 transaction_id TEXT,
 reject_reason TEXT,
 approved_at TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL);

CREATE INDEX IF NOT EXISTS idx_book_user   ON book_orders(user_id);
CREATE INDEX IF NOT EXISTS idx_book_status ON book_orders(status);

CREATE TABLE IF NOT EXISTS audit_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor_id INTEGER NOT NULL,
 action TEXT NOT NULL,
 target_id INTEGER,
 detail TEXT,
 created_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS conversation_state (
 user_id INTEGER PRIMARY KEY,
 state TEXT NOT NULL,
 data TEXT NOT NULL,
 updated_at TEXT NOT NULL);
"""

PLAN_DAYS = {"daily": 1, "weekly": 7, "monthly": 30}


class Database:
    def __init__(self, path: str = None):
        self.path = path or config.DB_PATH

    async def init(self):
        async with aiosqlite.connect(self.path) as db:
            await db.executescript(SCHEMA)
            await db.commit()
        logger.info("DB ready: %s", self.path)

    @asynccontextmanager
    async def connect(self):
        for attempt in range(3):
            try:
                db = await aiosqlite.connect(self.path)
                db.row_factory = aiosqlite.Row
                try:
                    yield db
                finally:
                    await db.close()
                return
            except Exception:
                if attempt == 2:
                    raise
                await asyncio.sleep(0.5 * (attempt + 1))

    async def create_registration(self, **kw) -> int:
        now = datetime.utcnow().isoformat(timespec="seconds")
        async with self.connect() as db:
            cur = await db.execute(
                """INSERT INTO registrations
                (user_id,username,full_name,phone,address,students,grade,
                 schedule,price,hours_per_day,payment_plan,status,
                 receipt_file,transaction_id,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,'Pending',?,?,?,?)""",
                (kw["user_id"], kw.get("username"), kw["full_name"], kw["phone"],
                 kw["address"], kw["students"], kw.get("grade"), kw["schedule"],
                 kw.get("price"), kw.get("hours_per_day"), kw.get("payment_plan"),
                 kw.get("receipt_file"), kw.get("transaction_id"), now, now),
            )
            await db.commit()
            return cur.lastrowid

    async def set_status(self, user_id: int, status: str,
                         notes: str = None, reason: str = None) -> None:
        now = datetime.utcnow().isoformat(timespec="seconds")
        async with self.connect() as db:
            await db.execute(
                "UPDATE registrations SET status=?,admin_notes=?,reject_reason=?,updated_at=? "
                "WHERE user_id=? AND status='Pending'",
                (status, notes, reason, now, user_id),
            )
            await db.commit()

    async def approve_and_schedule(self, user_id: int) -> dict | None:
        async with self.connect() as db:
            cur = await db.execute(
                "SELECT payment_plan FROM registrations WHERE user_id=? "
                "AND status='Pending' ORDER BY id DESC LIMIT 1",
                (user_id,),
            )
            row = await cur.fetchone()
            if not row:
                return None
            plan = row["payment_plan"] or "monthly"
            days = PLAN_DAYS.get(plan, 30)
            now = datetime.utcnow()
            due = (now + timedelta(days=days)).isoformat(timespec="seconds")
            await db.execute(
                "UPDATE registrations SET status='Approved', approved_at=?, "
                "next_payment_due=?, updated_at=? WHERE user_id=? AND status='Pending'",
                (now.isoformat(timespec="seconds"), due,
                 now.isoformat(timespec="seconds"), user_id),
            )
            await db.commit()
            return {"plan": plan, "days": days, "next_due": due}

    async def get_due_reminders(self, days_before: int = 2) -> list[dict]:
        now = datetime.utcnow()
        horizon = (now + timedelta(days=days_before)).isoformat(timespec="seconds")
        async with self.connect() as db:
            cur = await db.execute(
                "SELECT * FROM registrations WHERE status='Approved' "
                "AND next_payment_due IS NOT NULL AND next_payment_due <= ? "
                "ORDER BY next_payment_due",
                (horizon,),
            )
            return [dict(r) for r in await cur.fetchall()]

    async def get_by_user(self, user_id: int) -> list[dict]:
        async with self.connect() as db:
            cur = await db.execute(
                "SELECT * FROM registrations WHERE user_id=? ORDER BY id DESC",
                (user_id,),
            )
            return [dict(r) for r in await cur.fetchall()]

    async def list_registrations(self, status: str = None, limit=50, offset=0) -> list[dict]:
        q = "SELECT * FROM registrations"
        p: list[Any] = []
        if status:
            q += " WHERE status=?"
            p.append(status)
        q += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        p += [limit, offset]
        async with self.connect() as db:
            cur = await db.execute(q, p)
            return [dict(r) for r in await cur.fetchall()]

    async def stats(self) -> dict:
        async with self.connect() as db:
            cur = await db.execute("SELECT COUNT(*) FROM registrations")
            total = (await cur.fetchone())[0]
            cur = await db.execute("SELECT status,COUNT(*) FROM registrations GROUP BY status")
            by = {r[0]: r[1] for r in await cur.fetchall()}
            cur = await db.execute(
                "SELECT COUNT(*) FROM registrations WHERE date(created_at)=date('now')"
            )
            today = (await cur.fetchone())[0]
        return {"total": total, "by_status": by, "today": today}

    async def export_rows(self) -> list[dict]:
        async with self.connect() as db:
            cur = await db.execute("SELECT * FROM registrations ORDER BY id")
            return [dict(r) for r in await cur.fetchall()]

    # ───── BOOK ORDERS ─────
    async def create_book_order(self, **kw) -> int:
        now = datetime.utcnow().isoformat(timespec="seconds")
        async with self.connect() as db:
            cur = await db.execute(
                """INSERT INTO book_orders
                (user_id,username,full_name,phone,order_type,category,amount,
                 status,receipt_file,transaction_id,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,'Pending',?,?,?,?)""",
                (kw["user_id"], kw.get("username"), kw.get("full_name"), kw.get("phone"),
                 kw["order_type"], kw.get("category"), kw["amount"],
                 kw.get("receipt_file"), kw.get("transaction_id"), now, now),
            )
            await db.commit()
            return cur.lastrowid

    async def set_book_order_status(self, order_id: int, status: str,
                                    reason: str = None) -> None:
        now = datetime.utcnow().isoformat(timespec="seconds")
        async with self.connect() as db:
            await db.execute(
                "UPDATE book_orders SET status=?, reject_reason=?, approved_at=?, "
                "updated_at=? WHERE id=? AND status='Pending'",
                (status, reason,
                 now if status == "Approved" else None,
                 now, order_id),
            )
            await db.commit()

    async def get_book_order(self, order_id: int) -> dict | None:
        async with self.connect() as db:
            cur = await db.execute("SELECT * FROM book_orders WHERE id=?", (order_id,))
            row = await cur.fetchone()
            return dict(row) if row else None

    async def user_has_bookstore_access(self, user_id: int) -> bool:
        async with self.connect() as db:
            cur = await db.execute(
                "SELECT COUNT(*) FROM book_orders WHERE user_id=? "
                "AND order_type='subscription' AND status='Approved'",
                (user_id,),
            )
            return (await cur.fetchone())[0] > 0

    async def user_has_group_access(self, user_id: int) -> bool:
        async with self.connect() as db:
            cur = await db.execute(
                "SELECT COUNT(*) FROM book_orders WHERE user_id=? "
                "AND order_type='group' AND status='Approved'",
                (user_id,),
            )
            return (await cur.fetchone())[0] > 0

    async def audit(self, actor_id: int, action: str,
                    target_id: int = None, detail: str = ""):
        async with self.connect() as db:
            await db.execute(
                "INSERT INTO audit_log (actor_id,action,target_id,detail,created_at) "
                "VALUES (?,?,?,?,?)",
                (actor_id, action, target_id, detail,
                 datetime.utcnow().isoformat(timespec="seconds")),
            )
            await db.commit()

    async def save_state(self, user_id: int, state: str, data: dict):
        async with self.connect() as db:
            await db.execute(
                """INSERT INTO conversation_state (user_id,state,data,updated_at)
                VALUES (?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET
                state=excluded.state, data=excluded.data, updated_at=excluded.updated_at""",
                (user_id, state, json.dumps(data, ensure_ascii=False),
                 datetime.utcnow().isoformat(timespec="seconds")),
            )
            await db.commit()

    async def clear_state(self, user_id: int):
        async with self.connect() as db:
            await db.execute("DELETE FROM conversation_state WHERE user_id=?", (user_id,))
            await db.commit()


db = Database()