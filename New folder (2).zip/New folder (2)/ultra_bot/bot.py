from telegram import BotCommand
from telegram.ext import (
    Application, CallbackQueryHandler, CommandHandler,
    MessageHandler, filters,
)
from config import config
from database import db
from handlers import admin, common, registration, bookstore
from utils.logger import error_handler, logger
from utils.reminders import schedule_reminders


async def _post_init(app: Application):
    await db.init()
    await app.bot.set_my_commands([
        BotCommand("start", "ምዝገባ ጀምር"),
        BotCommand("bookstore", "የመጽሐፍ መደብር"),
        BotCommand("status", "ሁኔታዬ"),
        BotCommand("about", "ስለ Ej Tutor"),
        BotCommand("help", "እርዳታ"),
        BotCommand("cancel", "ሰርዝ"),
    ])
    logger.info("Bot ready. Admins=%s", config.ADMIN_IDS)
    schedule_reminders(app.job_queue)


def build_app() -> Application:
    app = Application.builder().token(config.BOT_TOKEN).post_init(_post_init).build()

    app.add_handler(registration.build_conversation())
    app.add_handler(bookstore.build_book_conversation())

    app.add_handler(CommandHandler("stats",     admin.stats_cmd))
    app.add_handler(CommandHandler("export",    admin.export_cmd))
    app.add_handler(CommandHandler("pending",   admin.pending_cmd))
    app.add_handler(CommandHandler("search",    admin.search_cmd))
    app.add_handler(CommandHandler("backup",    admin.backup_cmd))
    app.add_handler(CommandHandler("broadcast", admin.broadcast_cmd))
    app.add_handler(CommandHandler("audit",     admin.audit_cmd))

    app.add_handler(CommandHandler("help",      common.help_cmd))
    app.add_handler(CommandHandler("about",     common.about_cmd))
    app.add_handler(CommandHandler("status",    common.status_cmd))
    app.add_handler(CommandHandler("cancel",    registration.cancel))

    app.add_handler(CallbackQueryHandler(
        admin.decision_callback,
        pattern="^(approve|reject|reason|back)_",
    ))
    app.add_handler(CallbackQueryHandler(
        admin.book_decision_callback,
        pattern="^(bapprove|breject|breason|bback)_",
    ))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, common.menu_text))
    app.add_error_handler(error_handler)
    return app


def main():
    app = build_app()
    logger.info("🚀 polling...")
    app.run_polling(allowed_updates=None, drop_pending_updates=True)


if __name__ == "__main__":
    main()