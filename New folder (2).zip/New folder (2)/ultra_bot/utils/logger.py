import logging, traceback
from telegram import Update
from config import config

logging.basicConfig(
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    level=getattr(logging, config.LOG_LEVEL, logging.INFO),
)
logger = logging.getLogger("ultra_bot")


async def error_handler(update: object, context):
    logger.error("Unhandled", exc_info=context.error)
    tb = "".join(traceback.format_exception(None, context.error, context.error.__traceback__))
    alert = f"⚠️ <b>Error</b>\n<pre>{tb[-1500:]}</pre>"
    for aid in config.ADMIN_IDS:
        try:
            await context.bot.send_message(chat_id=aid, text=alert, parse_mode="HTML")
        except Exception:
            pass
    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text("😔 ስህተት።\n/start ይጫኑ።")
        except Exception:
            pass