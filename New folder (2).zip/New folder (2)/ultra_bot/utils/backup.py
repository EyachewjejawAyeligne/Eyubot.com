import os, sqlite3
from datetime import datetime
from config import config


def snapshot() -> str:
    os.makedirs(config.BACKUP_DIR, exist_ok=True)
    fname = f"{config.BACKUP_DIR}/registrations_{datetime.now():%Y%m%d_%H%M%S}.db"
    src = sqlite3.connect(config.DB_PATH)
    dst = sqlite3.connect(fname)
    with dst:
        src.backup(dst)
    dst.close()
    src.close()
    return fname