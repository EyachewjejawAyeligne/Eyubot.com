import asyncio, logging
logger = logging.getLogger(__name__)


async def safe_send(bot, chat_id: int, text: str, retries: int = 3, **kw) -> bool:
    for i in range(retries):
        try:
            await bot.send_message(chat_id=chat_id, text=text, **kw)
            return True
        except Exception as e:
            logger.warning("send %s retry %s: %s", chat_id, i + 1, e)
            await asyncio.sleep(1.5 * (i + 1))
    return False