import logging
from datetime import datetime
from telegram.ext import ContextTypes
from config import config
from database import db
from keyboards import channel_group_inline
from texts import t, PLAN_LABELS

logger = logging.getLogger(__name__)


async def check_due_payments(context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        rows = await db.get_due_reminders(days_before=config.REMINDER_DAYS_BEFORE)
        logger.info("Reminder check: %d registrations due", len(rows))
        for r in rows:
            try:
                due = datetime.fromisoformat(r["next_payment_due"])
                days_left = (due.date() - datetime.utcnow().date()).days
                plan_label = PLAN_LABELS.get(r["payment_plan"] or "monthly", "በየወሩ")
                if days_left <= 0:
                    text = t("reminder_today", name=r["full_name"],
                             due=due.strftime("%Y-%m-%d"), plan=plan_label)
                else:
                    text = t("reminder", name=r["full_name"], days=days_left,
                             due=due.strftime("%Y-%m-%d"), plan=plan_label)
                await context.bot.send_message(
                    chat_id=r["user_id"], text=text,
                    reply_markup=channel_group_inline(
                        config.CHANNEL_LINK, config.GROUP_LINK
                    ),
                    parse_mode="HTML",
                )
                logger.info("Reminder sent to %s", r["user_id"])
            except Exception as e:
                logger.warning("reminder to %s failed: %s", r.get("user_id"), e)
    except Exception:
        logger.exception("Reminder check failed")


def schedule_reminders(job_queue) -> None:
    job_queue.run_daily(
        check_due_payments,
        time=datetime.now().replace(
            hour=config.REMINDER_HOUR, minute=0, second=0, microsecond=0
        ).timetz(),
        name="daily_payment_reminders",
    )
    logger.info("Reminder scheduler started (daily at %02d:00)", config.REMINDER_HOUR)