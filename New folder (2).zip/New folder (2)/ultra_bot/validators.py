import re

PHONE_RE = re.compile(r"^\+?\d{9,15}$")


def validate_name(text: str, max_len: int = 100) -> str | None:
    t = (text or "").strip()
    if len(t) < 2:
        return "⚠️ ስሙ በጣም አጭር ነው።"
    if len(t) > max_len:
        return f"⚠️ ከ {max_len} ፊደል መብለጥ የለበትም።"
    if any(c in t for c in "<>"):
        return "⚠️ ልክ ያልሆነ ፊደል ተገኝቷል።"
    return None


def validate_phone(text: str) -> str | None:
    t = (text or "").strip().replace(" ", "").replace("-", "")
    if not PHONE_RE.match(t):
        return "⚠️ እባክዎ ትክክለኛ ስልክ ቁጥር ያስገቡ።"
    return None


def validate_address(text: str, max_len: int = 200) -> str | None:
    t = (text or "").strip()
    if len(t) < 3:
        return "⚠️ አድራሻው በጣም አጭር ነው።"
    if len(t) > max_len:
        return f"⚠️ ከ {max_len} ፊደል መብለጥ የለበትም።"
    return None


def validate_children_count(text: str, min_children: int = 1,
                            max_children: int = 50) -> tuple[int | None, str | None]:
    try:
        n = int(text.strip())
    except (ValueError, AttributeError):
        return None, "⚠️ ቁጥር ብቻ ያስገቡ።"
    if n < min_children:
        return None, f"⚠️ ቢያንስ {min_children} ልጅ መሆን አለበት።"
    if n > max_children:
        return None, f"⚠️ ቢበዛ {max_children} ልጆች ብቻ።"
    return n, None


def sanitize(text: str, max_len: int = 500) -> str:
    return (text or "").strip()[:max_len]