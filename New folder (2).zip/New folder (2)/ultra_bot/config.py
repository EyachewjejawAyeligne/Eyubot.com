import os
from dataclasses import dataclass, field
from dotenv import load_dotenv

load_dotenv()


def _int_list(v: str) -> list[int]:
    return [int(x.strip()) for x in v.split(",") if x.strip().isdigit()]


@dataclass(frozen=True)
class Config:
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
    ADMIN_IDS: list[int] = field(default_factory=lambda: _int_list(os.getenv("ADMIN_IDS", "0")))
    DB_PATH: str = os.getenv("DB_PATH", "registrations.db")
    BACKUP_DIR: str = os.getenv("BACKUP_DIR", "backups")

    RATE_LIMIT_SECONDS: int = int(os.getenv("RATE_LIMIT_SECONDS", "2"))
    MAX_MESSAGES_PER_MIN: int = int(os.getenv("MAX_MESSAGES_PER_MIN", "30"))
    MIN_CHILDREN: int = int(os.getenv("MIN_CHILDREN", "1"))
    SANITY_MAX_CHILDREN: int = 50
    MAX_NAME_LEN: int = 100
    MAX_ADDRESS_LEN: int = 200

    # Tutoring price
    PRICE_PER_HOUR: int = int(os.getenv("PRICE_PER_HOUR", "600"))

    # Book store prices
    BOOKSTORE_SUBSCRIPTION_PRICE: int = int(os.getenv("BOOKSTORE_SUBSCRIPTION_PRICE", "300"))
    BOOKSTORE_GROUP_PRICE: int = int(os.getenv("BOOKSTORE_GROUP_PRICE", "700"))

    # Banks — all under Eyachew Jejaw
    CBE_ACCOUNT: str = os.getenv("CBE_ACCOUNT", "1000506789072")
    DASHEN_ACCOUNT: str = os.getenv("DASHEN_ACCOUNT", "5444116801011")
    ABYSSINIA_ACCOUNT: str = os.getenv("ABYSSINIA_ACCOUNT", "247179976")
    TELEBIRR: str = os.getenv("TELEBIRR", "0933476907")
    BANK_HOLDER_NAME: str = os.getenv("BANK_HOLDER_NAME", "Eyachew Jejaw")

    # Contact / Help Center
    CONTACT_PHONE: str = os.getenv("CONTACT_PHONE", "0907328272")
    HELP_CENTER_PHONE: str = os.getenv("HELP_CENTER_PHONE", "0907328272")

    # Channel & groups
    CHANNEL_LINK: str = os.getenv("CHANNEL_LINK", "")
    GROUP_LINK: str = os.getenv("GROUP_LINK", "")
    STORY_BOOKS_LINK: str = os.getenv("STORY_BOOKS_LINK", "")
    ACADEMIC_BOOKS_LINK: str = os.getenv("ACADEMIC_BOOKS_LINK", "")
    ENGLISH_BOOKS_LINK: str = os.getenv("ENGLISH_BOOKS_LINK", "")
    BOOKSTORE_GROUP_LINK: str = os.getenv("BOOKSTORE_GROUP_LINK", "")

    # Reminders
    REMINDER_HOUR: int = int(os.getenv("REMINDER_HOUR", "9"))
    REMINDER_DAYS_BEFORE: int = int(os.getenv("REMINDER_DAYS_BEFORE", "2"))

    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    def __post_init__(self):
        if not self.BOT_TOKEN:
            raise ValueError("BOT_TOKEN required in .env")
        if not self.ADMIN_IDS or self.ADMIN_IDS == [0]:
            raise ValueError("ADMIN_IDS required in .env")


config = Config()