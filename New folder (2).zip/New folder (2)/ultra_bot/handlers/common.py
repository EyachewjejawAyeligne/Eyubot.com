from config import config
from database import db
from keyboards import main_menu
from texts import t, PLAN_LABELS, HOURS_LABELS


async def help_cmd(update, context):
    await update.message.reply_text(
        t("help", help_phone=config.HELP_CENTER_PHONE),
        parse_mode="HTML", reply_markup=main_menu(),
    )


async def about_cmd(update, context):
    await update.message.reply_text(
        t("about", phone=config.CONTACT_PHONE, price=config.PRICE_PER_HOUR),
        parse_mode="HTML", reply_markup=main_menu(),
    )


async def status_cmd(update, context):
    rows = await db.get_by_user(update.effective_user.id)
    if not rows:
        await update.message.reply_text(
            t("status_empty"), parse_mode="HTML", reply_markup=main_menu()
        )
        return
    out = [t("status_header")]
    for r in rows:
        plan_label = PLAN_LABELS.get(r.get("payment_plan") or "monthly", "በየወሩ")
        hours_label = HOURS_LABELS.get(r.get("hours_per_day") or "1", "1 ሰዓት")
        status_emoji = {"Pending": "⏳", "Approved": "✅", "Rejected": "❌"}.get(r["status"], "❔")
        out.append(
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"#{r['id']} — {status_emoji} <b>{r['status']}</b>\n"
            f"   👨‍🎓 {r['students']}\n"
            f"   🕒 {r['schedule']}\n"
            f"   ⏰ {hours_label} | 📅 {plan_label}\n"
            f"   📅 {r['created_at'].split('T')[0]}\n"
        )
    await update.message.reply_text(
        "\n".join(out), parse_mode="HTML", reply_markup=main_menu()
    )


async def menu_text(update, context):
    text = update.message.text or ""
    if "ስለ እኛ" in text or "About" in text:
        return await about_cmd(update, context)
    if "ሁኔታዬ" in text or "My Status" in text:
        return await status_cmd(update, context)
    if "እርዳታ" in text or "Help" in text:
        return await help_cmd(update, context)
    if "ሰርዝ" in text:
        await update.message.reply_text(
            t("cancelled"), parse_mode="HTML", reply_markup=main_menu()
        )
        return
    await update.message.reply_text(
        t("unknown"), parse_mode="HTML", reply_markup=main_menu()
    )