import csv, io, logging, os, sqlite3
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from config import config
from database import db
from middleware import admin_only
from keyboards import (
    admin_decision, admin_reject_reasons,
    admin_book_decision, admin_book_reject_reasons,
    channel_group_inline,
)
from texts import t, PLAN_LABELS, HOURS_LABELS

logger = logging.getLogger(__name__)

REJECT_REASONS = {
    "no_time":     "⏰ ነፃ ጊዜ የለም",
    "no_payment":  "💰 ክፍያ አልተረጋገጠም",
    "no_subject":  "📚 ትምህርት አልተገኘም",
    "no_contact":  "📵 ስልክ አልተገኘም",
    "other":       "🚫 ሌላ ምክንያት",
}

BOOK_REJECT_REASONS = {
    "no_payment": "💰 ክፍያ አልተረጋገጠም",
    "other":      "🚫 ሌላ ምክንያት",
}


@admin_only
async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    s = await db.stats()
    by = s["by_status"]
    async with db.connect() as conn:
        cur = await conn.execute("SELECT COUNT(*) FROM book_orders")
        books = (await cur.fetchone())[0]
        cur = await conn.execute("SELECT COUNT(*) FROM book_orders WHERE status='Approved'")
        books_ok = (await cur.fetchone())[0]
    await update.message.reply_text(
        f"📈 <b>ስታቲስቲክስ</b>\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🎓 <b>ትምህርት</b>\n"
        f"   📊 ጠቅላላ፦ {s['total']}\n"
        f"   📅 ዛሬ፦ {s['today']}\n"
        f"   ⏳ Pending፦ {by.get('Pending', 0)}\n"
        f"   ✅ Approved፦ {by.get('Approved', 0)}\n"
        f"   ❌ Rejected፦ {by.get('Rejected', 0)}\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📚 <b>የመጽሐፍ መደብር</b>\n"
        f"   📦 ጠቅላላ፦ {books}\n"
        f"   ✅ Approved፦ {books_ok}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━",
        parse_mode="HTML",
    )


@admin_only
async def export_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = await db.export_rows()
    if not rows:
        await update.message.reply_text("📭 ምንም መረጃ የለም።")
        return
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([
        "ID", "User ID", "Full Name", "Phone", "Address", "Students",
        "Grade", "Schedule", "Price", "Hours/Day", "Plan", "Status",
        "Transaction ID", "Reject Reason", "Approved At", "Next Due", "Created",
    ])
    for r in rows:
        w.writerow([
            r["id"], r["user_id"], r["full_name"], r["phone"], r["address"],
            r["students"], r.get("grade"), r["schedule"], r.get("price"),
            r.get("hours_per_day"), r.get("payment_plan"), r["status"],
            r.get("transaction_id"), r.get("reject_reason"),
            r.get("approved_at"), r.get("next_payment_due"), r["created_at"],
        ])
    data = io.BytesIO(("\ufeff" + buf.getvalue()).encode("utf-8"))
    fname = f"registrations_{datetime.now():%Y%m%d_%H%M}.csv"
    await update.message.reply_document(
        document=data, filename=fname,
        caption=f"📊 <b>ሪፖርት</b> ({len(rows)} ረድፎች)", parse_mode="HTML",
    )


@admin_only
async def pending_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = await db.list_registrations(status="Pending", limit=10)
    if not rows:
        await update.message.reply_text("✅ ምንም በመጠባበቅ ላይ የለም።")
        return
    out = [f"⏳ <b>በመጠባበቅ ({len(rows)})</b>\n"]
    for r in rows:
        plan = PLAN_LABELS.get(r.get("payment_plan") or "monthly", "በየወሩ")
        hours = HOURS_LABELS.get(r.get("hours_per_day") or "1", "1 ሰዓት")
        out.append(
            f"#{r['id']} — <b>{r['full_name']}</b> | {r['phone']}\n"
            f"   👨‍🎓 {r['students']}\n"
            f"   🕒 {r['schedule']} | ⏰ {hours}\n"
            f"   💰 {r.get('price')} ብር | 📅 {plan}\n"
            f"   💬 <code>{r['user_id']}</code>"
        )
    await update.message.reply_text("\n".join(out), parse_mode="HTML")


@admin_only
async def search_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await update.message.reply_text("አጠቃቀም፦ /search <ስልክ ወይም ስም>")
        return
    q = " ".join(context.args).strip()
    async with db.connect() as conn:
        cur = await conn.execute(
            "SELECT * FROM registrations WHERE phone LIKE ? OR full_name LIKE ? "
            "ORDER BY id DESC LIMIT 20",
            (f"%{q}%", f"%{q}%"),
        )
        rows = [dict(r) for r in await cur.fetchall()]
    if not rows:
        await update.message.reply_text(f"🔍 '{q}' — ምንም አልተገኘም።")
        return
    out = [f"🔍 <b>'{q}' — {len(rows)} ውጤቶች</b>\n"]
    for r in rows:
        out.append(
            f"#{r['id']} <b>{r['full_name']}</b> | {r['phone']} | {r['status']}\n"
            f"   👨‍🎓 {r['students']}"
        )
    await update.message.reply_text("\n".join(out), parse_mode="HTML")


@admin_only
async def backup_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    os.makedirs(config.BACKUP_DIR, exist_ok=True)
    fname = f"{config.BACKUP_DIR}/registrations_{datetime.now():%Y%m%d_%H%M%S}.db"
    try:
        src = sqlite3.connect(config.DB_PATH)
        dst = sqlite3.connect(fname)
        with dst:
            src.backup(dst)
        dst.close()
        src.close()
        with open(fname, "rb") as f:
            await update.message.reply_document(
                document=f, filename=os.path.basename(fname),
                caption="💾 <b>DB ባክአፕ</b>", parse_mode="HTML",
            )
    except Exception as e:
        logger.exception("backup")
        await update.message.reply_text(f"❌ {e}")


@admin_only
async def broadcast_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await update.message.reply_text("አጠቃቀም፦ /broadcast <መልእክት>")
        return
    msg = " ".join(context.args)
    async with db.connect() as conn:
        cur = await conn.execute(
            "SELECT DISTINCT user_id FROM registrations WHERE status='Approved'"
        )
        uids = [r["user_id"] for r in await cur.fetchall()]
    ok = fail = 0
    status = await update.message.reply_text(f"📤 0/{len(uids)}")
    for i, uid in enumerate(uids, 1):
        try:
            await context.bot.send_message(chat_id=uid, text=msg)
            ok += 1
        except Exception as e:
            logger.warning("%s: %s", uid, e)
            fail += 1
        if i % 10 == 0:
            try:
                await status.edit_text(f"📤 {i}/{len(uids)}")
            except Exception:
                pass
    await status.edit_text(f"✅ ተጠናቅቋል\n📨 ተልኳል፦ {ok}\n❌ አልተላከም፦ {fail}")


@admin_only
async def audit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    async with db.connect() as conn:
        cur = await conn.execute(
            "SELECT actor_id, action, target_id, detail, created_at "
            "FROM audit_log ORDER BY id DESC LIMIT 20"
        )
        rows = await cur.fetchall()
    if not rows:
        await update.message.reply_text("📭 ኦዲት መዝገብ የለም።")
        return
    out = ["🗂 <b>የመጨረሻ ኦዲት</b>\n"]
    for r in rows:
        out.append(
            f"• <code>{r['created_at']}</code> — {r['action']} "
            f"(actor {r['actor_id']}) {r['detail'] or ''}"
        )
    await update.message.reply_text("\n".join(out), parse_mode="HTML")


# ───── TUTORING approve/reject ─────
async def decision_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    await q.answer()
    if update.effective_user.id not in config.ADMIN_IDS:
        await q.answer("⛔", show_alert=True)
        return
    action, _, rest = q.data.partition("_")
    try:
        target = int(rest.split("_")[0])
    except ValueError:
        return
    if action == "approve":
        result = await db.approve_and_schedule(target)
        if not result:
            await q.answer("⚠️", show_alert=True)
            return
        plan_label = PLAN_LABELS.get(result["plan"], result["plan"])
        due_human = result["next_due"].split("T")[0]
        try:
            await context.bot.send_message(
                chat_id=target,
                text=t("approved", plan=plan_label, due=due_human,
                       help_phone=config.HELP_CENTER_PHONE),
                reply_markup=channel_group_inline(
                    config.CHANNEL_LINK, config.GROUP_LINK
                ),
                parse_mode="HTML",
            )
        except Exception as e:
            logger.warning("notify approved: %s", e)
        stamp = f"\n\n<b>[✅ Approved — {plan_label} | next due {due_human}]</b>"
        await _update_admin_card(q, stamp)
        await db.audit(update.effective_user.id, "approve", target, detail=result["plan"])
        return
    if action == "reject":
        try:
            await q.edit_message_reply_markup(reply_markup=admin_reject_reasons(target))
        except Exception:
            await q.message.reply_text(
                f"ለ #{target} ምክንያት ይምረጡ፦",
                reply_markup=admin_reject_reasons(target),
            )
        return
    if action == "reason":
        parts = q.data.split("_", 2)
        if len(parts) != 3:
            return
        _, uid, code = parts
        target = int(uid)
        reason = REJECT_REASONS.get(code, "ሌላ")
        await db.set_status(target, "Rejected", reason=reason)
        try:
            await context.bot.send_message(
                chat_id=target,
                text=t("rejected_reason", reason=reason,
                       phone=config.HELP_CENTER_PHONE),
                parse_mode="HTML",
            )
        except Exception as e:
            logger.warning("notify reject: %s", e)
        stamp = f"\n\n<b>[❌ Rejected — {reason}]</b>"
        await _update_admin_card(q, stamp)
        await db.audit(update.effective_user.id, "reject", target, detail=reason)
        return
    if action == "back":
        try:
            await q.edit_message_reply_markup(reply_markup=admin_decision(target))
        except Exception:
            pass


# ───── BOOK approve/reject ─────
async def book_decision_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    await q.answer()
    if update.effective_user.id not in config.ADMIN_IDS:
        await q.answer("⛔", show_alert=True)
        return
    action, _, rest = q.data.partition("_")
    try:
        order_id = int(rest.split("_")[0])
    except ValueError:
        return
    if action == "bapprove":
        order = await db.get_book_order(order_id)
        if not order:
            await q.answer("⚠️", show_alert=True)
            return
        await db.set_book_order_status(order_id, "Approved")
        try:
            link = (
                config.STORY_BOOKS_LINK
                if order["order_type"] == "subscription"
                else config.BOOKSTORE_GROUP_LINK
            )
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("📚 አሁን ይግቡ", url=link)]
            ])
            await context.bot.send_message(
                chat_id=order["user_id"],
                text=t("book_order_approved"),
                reply_markup=kb, parse_mode="HTML",
            )
        except Exception as e:
            logger.warning("book notify approved: %s", e)
        stamp = "\n\n<b>[✅ Book Order Approved]</b>"
        await _update_admin_card(q, stamp)
        return
    if action == "breject":
        try:
            await q.edit_message_reply_markup(
                reply_markup=admin_book_reject_reasons(order_id)
            )
        except Exception:
            pass
        return
    if action == "breason":
        parts = q.data.split("_", 2)
        if len(parts) != 3:
            return
        _, oid, code = parts
        order_id = int(oid)
        reason = BOOK_REJECT_REASONS.get(code, "ሌላ")
        order = await db.get_book_order(order_id)
        await db.set_book_order_status(order_id, "Rejected", reason=reason)
        if order:
            try:
                await context.bot.send_message(
                    chat_id=order["user_id"],
                    text=t("book_order_rejected",
                           reason=reason, phone=config.HELP_CENTER_PHONE),
                    parse_mode="HTML",
                )
            except Exception as e:
                logger.warning("book notify reject: %s", e)
        stamp = f"\n\n<b>[❌ Book Rejected — {reason}]</b>"
        await _update_admin_card(q, stamp)
        return
    if action == "bback":
        try:
            await q.edit_message_reply_markup(
                reply_markup=admin_book_decision(order_id)
            )
        except Exception:
            pass


async def _update_admin_card(q, stamp: str):
    try:
        if q.message.caption is not None:
            await q.edit_message_caption(
                caption=(q.message.caption or "") + stamp, parse_mode="HTML",
            )
        else:
            await q.edit_message_text(
                (q.message.text or "") + stamp, parse_mode="HTML",
            )
    except Exception:
        pass