import logging
from telegram import Update
from telegram.ext import (
    CallbackQueryHandler, CommandHandler, ContextTypes,
    ConversationHandler, MessageHandler, filters,
)
from config import config
from database import db
from keyboards import (
    cancel_only, main_menu, phone_request,
    grade_inline, hours_per_day_inline, schedule_inline,
    confirm_price_inline, payment_plan_inline, admin_decision,
)
from middleware import rate_limited
from texts import t, PLAN_LABELS, HOURS_LABELS
from validators import sanitize

logger = logging.getLogger(__name__)

(
    FULL_NAME, PHONE, ADDRESS, NUM_CHILDREN,
    STUDENT_NAME, STUDENT_GRADE,
    HOURS_PER_DAY, SCHEDULE_SELECTION, PRICE_CONFIRM,
    PAYMENT_PLAN, PAYMENT_UPLOAD,
) = range(11)

SCHEDULE_MAP = {
    "sched_weekend_morning":   "ቅዳሜ እና እሁድ (ጠዋት)",
    "sched_weekend_afternoon": "ቅዳሜ እና እሁድ (ከሰዓት)",
    "sched_weekday":           "ከሰኞ - አርብ (ከሰዓት በኋላ)",
}

GRADE_MAP = {
    "kg": "KG",
    "1": "1ኛ ክፍል", "2": "2ኛ ክፍል", "3": "3ኛ ክፍል",
    "4": "4ኛ ክፍል", "5": "5ኛ ክፍል", "6": "6ኛ ክፍል",
    "7": "7ኛ ክፍል", "8": "8ኛ ክፍል", "9": "9ኛ ክፍል",
    "10": "10ኛ ክፍል", "11": "11ኛ ክፍል", "12": "12ኛ ክፍል",
    "special": "ልዩ ፍላጎት (Special Needs)",
}


def _daily_total(hours_str: str) -> int:
    try:
        h = float(hours_str)
    except (TypeError, ValueError):
        h = 1
    return int(config.PRICE_PER_HOUR * h)


async def _save(update, context, state):
    try:
        await db.save_state(update.effective_user.id, state, context.user_data)
    except Exception as e:
        logger.warning("save_state: %s", e)


async def entry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    context.user_data["students"] = []
    user_name = update.effective_user.first_name or "ወላጅ"
    await update.message.reply_text(
        t("welcome", name=user_name), reply_markup=main_menu(), parse_mode="HTML",
    )
    await update.message.reply_text(
        t("ask_name"), reply_markup=cancel_only(), parse_mode="HTML"
    )
    return FULL_NAME


@rate_limited
async def get_full_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if "ሰርዝ" in (update.message.text or ""):
        return await cancel(update, context)
    name = sanitize(update.message.text, config.MAX_NAME_LEN)
    if len(name) < 2:
        await update.message.reply_text(t("name_too_short"), parse_mode="HTML")
        return FULL_NAME
    context.user_data["full_name"] = name
    await _save(update, context, "PHONE")
    await update.message.reply_text(t("ask_phone"), reply_markup=phone_request())
    return PHONE


@rate_limited
async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.text and "ሰርዝ" in update.message.text:
        return await cancel(update, context)
    raw = update.message.contact.phone_number if update.message.contact else update.message.text
    raw = (raw or "").strip().replace(" ", "").replace("-", "")
    if not raw.lstrip("+").isdigit() or len(raw) < 9:
        await update.message.reply_text(
            "⚠️ ትክክለኛ ስልክ ቁጥር ያስገቡ (ለምሳሌ፦ 0911223344)።"
        )
        return PHONE
    context.user_data["phone"] = raw
    await _save(update, context, "ADDRESS")
    await update.message.reply_text(t("ask_address"), reply_markup=cancel_only())
    return ADDRESS


@rate_limited
async def get_address(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if "ሰርዝ" in (update.message.text or ""):
        return await cancel(update, context)
    addr = sanitize(update.message.text, config.MAX_ADDRESS_LEN)
    if len(addr) < 3:
        await update.message.reply_text("⚠️ አድራሻው በጣም አጭር ነው።")
        return ADDRESS
    context.user_data["address"] = addr
    await _save(update, context, "NUM_CHILDREN")
    await update.message.reply_text(
        t("ask_children", min=config.MIN_CHILDREN),
        reply_markup=cancel_only(), parse_mode="HTML",
    )
    return NUM_CHILDREN


@rate_limited
async def get_num_children(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if "ሰርዝ" in (update.message.text or ""):
        return await cancel(update, context)
    try:
        n = int((update.message.text or "").strip())
    except ValueError:
        await update.message.reply_text(t("invalid_number"), parse_mode="HTML")
        return NUM_CHILDREN
    if n < config.MIN_CHILDREN:
        await update.message.reply_text(
            t("too_few_children", min=config.MIN_CHILDREN), parse_mode="HTML"
        )
        return NUM_CHILDREN
    if n > config.SANITY_MAX_CHILDREN:
        await update.message.reply_text(
            f"⚠️ ቢበዛ {config.SANITY_MAX_CHILDREN} ልጆች በአንድ ጊዜ መመዝገብ ይችላሉ።\n"
            "ለተጨማሪ ጥያቄ አስተዳዳሪውን ያግኙ።",
            parse_mode="HTML",
        )
        return NUM_CHILDREN
    context.user_data["num_children"] = n
    context.user_data["current_child"] = 1
    context.user_data["students"] = []
    await _save(update, context, "STUDENT_NAME")
    await update.message.reply_text(
        t("ask_student_first"), reply_markup=cancel_only(), parse_mode="HTML"
    )
    return STUDENT_NAME


@rate_limited
async def get_student_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if "ሰርዝ" in (update.message.text or ""):
        return await cancel(update, context)
    raw = sanitize(update.message.text, 100)
    if raw.isdigit():
        await update.message.reply_text(t("not_a_name"), parse_mode="HTML")
        return STUDENT_NAME
    if sum(1 for c in raw if c.isalpha()) < 2:
        await update.message.reply_text(t("name_too_short"), parse_mode="HTML")
        return STUDENT_NAME
    context.user_data["temp_student_name"] = raw
    idx = context.user_data["current_child"]
    await update.message.reply_text(
        t("ask_grade", n=idx), reply_markup=grade_inline(idx), parse_mode="HTML"
    )
    return STUDENT_GRADE


async def student_grade_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    parts = q.data.split("_", 2)
    if len(parts) != 3:
        return STUDENT_GRADE
    _, num_str, code = parts
    grade_label = GRADE_MAP.get(code, code)
    student = {
        "name": context.user_data.get("temp_student_name", ""),
        "grade": grade_label,
    }
    context.user_data["students"].append(student)
    context.user_data.pop("temp_student_name", None)
    cur = int(num_str)
    total = context.user_data["num_children"]
    if cur < total:
        context.user_data["current_child"] = cur + 1
        await q.edit_message_text(text=f"✅ {student['name']} — {grade_label}")
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=t("ask_student_next", n=cur + 1),
            reply_markup=cancel_only(), parse_mode="HTML",
        )
        return STUDENT_NAME
    await q.edit_message_text(text=f"✅ {student['name']} — {grade_label}")
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=t("ask_hours_per_day"),
        reply_markup=hours_per_day_inline(), parse_mode="HTML",
    )
    return HOURS_PER_DAY


async def hours_per_day_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    hours_code = q.data.replace("hours_", "")
    context.user_data["hours_per_day"] = hours_code
    hours_label = HOURS_LABELS.get(hours_code, hours_code)
    student_lines = "\n".join(
        f"   {i + 1}. {s['name']} — {s['grade']}"
        for i, s in enumerate(context.user_data["students"])
    )
    summary = t(
        "summary",
        name=context.user_data["full_name"],
        phone=context.user_data["phone"],
        address=context.user_data["address"],
        students=student_lines,
        hours_per_day=hours_label,
    )
    await q.edit_message_text(text=f"✅ {hours_label}")
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=summary, reply_markup=schedule_inline(), parse_mode="HTML",
    )
    return SCHEDULE_SELECTION


async def schedule_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    context.user_data["schedule"] = SCHEDULE_MAP.get(q.data, "መደበኛ")
    hours_label = HOURS_LABELS.get(context.user_data["hours_per_day"], "1 ሰዓት")
    daily = _daily_total(context.user_data["hours_per_day"])
    await q.edit_message_text(
        text=t(
            "price_info",
            price=config.PRICE_PER_HOUR,
            hours_per_day=hours_label,
            daily_total=daily,
            schedule=context.user_data["schedule"],
        ),
        reply_markup=confirm_price_inline(),
        parse_mode="HTML",
    )
    return PRICE_CONFIRM


async def price_confirmed(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    if q.data == "price_decline":
        await q.edit_message_text(
            "❌ ክፍያውን አልተቀበሉም።\nእንደገና ለመሞከር /start ይጫኑ።"
        )
        return ConversationHandler.END
    await q.edit_message_text(
        text=t("ask_payment_plan"),
        reply_markup=payment_plan_inline(),
        parse_mode="HTML",
    )
    return PAYMENT_PLAN


async def payment_plan_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    plan_code = q.data.replace("plan_", "")
    context.user_data["payment_plan"] = plan_code
    plan_label = PLAN_LABELS.get(plan_code, plan_code)
    hours_label = HOURS_LABELS.get(context.user_data["hours_per_day"], "1 ሰዓት")
    await q.edit_message_text(
        t(
            "payment",
            schedule=context.user_data["schedule"],
            price=config.PRICE_PER_HOUR,
            hours_per_day=hours_label,
            plan=plan_label,
            cbe=config.CBE_ACCOUNT,
            dashen=config.DASHEN_ACCOUNT,
            abyssinia=config.ABYSSINIA_ACCOUNT,
            telebirr=config.TELEBIRR,
            bank_holder=config.BANK_HOLDER_NAME,
        ),
        parse_mode="HTML",
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=t("upload_prompt"), reply_markup=cancel_only(), parse_mode="HTML",
    )
    return PAYMENT_UPLOAD


@rate_limited
async def payment_received(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.text and "ሰርዝ" in update.message.text:
        return await cancel(update, context)
    required = ["full_name", "phone", "address", "students",
                "schedule", "hours_per_day", "payment_plan"]
    missing = [k for k in required if k not in context.user_data or not context.user_data[k]]
    if missing:
        logger.warning("payment_received missing: %s", missing)
        await update.message.reply_text(
            "⚠️ የምዝገባ መረጃው ጠፍቷል።\nእባክዎ እንደገና /start ይጫኑ።",
            reply_markup=main_menu(),
        )
        return ConversationHandler.END
    file_id = None
    txid = None
    if update.message.photo:
        file_id = update.message.photo[-1].file_id
    elif update.message.text:
        txid = sanitize(update.message.text, 100)
        if len(txid) < 4:
            await update.message.reply_text(t("not_photo_or_text"), parse_mode="HTML")
            return PAYMENT_UPLOAD
    else:
        await update.message.reply_text(t("not_photo_or_text"), parse_mode="HTML")
        return PAYMENT_UPLOAD
    user = update.effective_user
    try:
        students_list = context.user_data["students"]
        students_str = "; ".join(f"{s['name']} ({s['grade']})" for s in students_list)
        grades_str = ", ".join(s["grade"] for s in students_list)
    except (KeyError, TypeError) as e:
        logger.error("students malformed: %s", e)
        await update.message.reply_text(
            "⚠️ የልጆች መረጃ ተበላሽቷል።\nእባክዎ /start ይጫኑ።",
            reply_markup=main_menu(),
        )
        return ConversationHandler.END
    try:
        reg_id = await db.create_registration(
            user_id=user.id, username=user.username,
            full_name=context.user_data["full_name"],
            phone=context.user_data["phone"],
            address=context.user_data["address"],
            students=students_str, grade=grades_str,
            schedule=context.user_data["schedule"],
            price=config.PRICE_PER_HOUR,
            hours_per_day=context.user_data["hours_per_day"],
            payment_plan=context.user_data["payment_plan"],
            receipt_file=file_id, transaction_id=txid,
        )
    except Exception as e:
        logger.exception("DB insert failed")
        await update.message.reply_text(
            f"⚠️ ስህተት ተከስቷል።\nእባክዎ /start ይጫኑ።\n{type(e).__name__}",
            reply_markup=main_menu(),
        )
        return ConversationHandler.END
    await db.clear_state(user.id)
    plan_label = PLAN_LABELS.get(context.user_data["payment_plan"], "በየወሩ")
    hours_label = HOURS_LABELS.get(context.user_data["hours_per_day"], "1 ሰዓት")
    caption = (
        f"🔔 <b>አዲስ ምዝገባ #{reg_id}</b>\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>ወላጅ፦</b> {context.user_data['full_name']}\n"
        f"📞 <b>ስልክ፦</b> {context.user_data['phone']}\n"
        f"📍 <b>አድራሻ፦</b> {context.user_data['address']}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👨‍🎓 <b>ተማሪዎች፦</b>\n"
    )
    for i, s in enumerate(context.user_data["students"], 1):
        caption += f"   {i}. {s['name']} — {s['grade']}\n"
    caption += (
        f"\n━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🕒 <b>መርሃ-ግብር፦</b> {context.user_data['schedule']}\n"
        f"⏰ <b>በቀን፦</b> {hours_label}\n"
        f"💰 <b>ዋጋ፦</b> {config.PRICE_PER_HOUR} ብር / ሰዓት\n"
        f"📅 <b>የክፍያ ዑደት፦</b> {plan_label}\n"
    )
    if txid:
        caption += f"🧾 <b>Transaction ID:</b> <code>{txid}</code>\n"
    if file_id:
        caption += "📷 <b>ደረሰኝ፦</b> ፎቶ ተያይዟል\n"
    caption += f"💬 <b>User ID:</b> <code>{user.id}</code>"
    sent = False
    for admin_id in config.ADMIN_IDS:
        try:
            if file_id:
                await context.bot.send_photo(
                    chat_id=admin_id, photo=file_id, caption=caption,
                    reply_markup=admin_decision(user.id), parse_mode="HTML",
                )
            else:
                await context.bot.send_message(
                    chat_id=admin_id, text=caption,
                    reply_markup=admin_decision(user.id), parse_mode="HTML",
                )
            sent = True
        except Exception as e:
            logger.error("admin notify %s: %s", admin_id, e)
    if not sent:
        logger.error("No admin notified. ADMIN_IDS=%s", config.ADMIN_IDS)
    await update.message.reply_text(
        t("payment_done", help_phone=config.HELP_CENTER_PHONE),
        reply_markup=main_menu(), parse_mode="HTML",
    )
    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        await db.clear_state(update.effective_user.id)
    except Exception:
        pass
    context.user_data.clear()
    await update.message.reply_text(t("cancelled"), reply_markup=main_menu())
    return ConversationHandler.END


def build_conversation() -> ConversationHandler:
    return ConversationHandler(
        entry_points=[
            CommandHandler("start", entry),
            MessageHandler(filters.Regex("^🚀"), entry),
        ],
        states={
            FULL_NAME:         [MessageHandler(filters.TEXT & ~filters.COMMAND, get_full_name)],
            PHONE:             [MessageHandler((filters.TEXT | filters.CONTACT) & ~filters.COMMAND, get_phone)],
            ADDRESS:           [MessageHandler(filters.TEXT & ~filters.COMMAND, get_address)],
            NUM_CHILDREN:      [MessageHandler(filters.TEXT & ~filters.COMMAND, get_num_children)],
            STUDENT_NAME:      [MessageHandler(filters.TEXT & ~filters.COMMAND, get_student_name)],
            STUDENT_GRADE:     [CallbackQueryHandler(student_grade_selected, pattern="^grade_")],
            HOURS_PER_DAY:     [CallbackQueryHandler(hours_per_day_selected, pattern="^hours_")],
            SCHEDULE_SELECTION:[CallbackQueryHandler(schedule_selected, pattern="^sched_")],
            PRICE_CONFIRM:     [CallbackQueryHandler(price_confirmed, pattern="^price_")],
            PAYMENT_PLAN:      [CallbackQueryHandler(payment_plan_selected, pattern="^plan_")],
            PAYMENT_UPLOAD:    [MessageHandler(filters.PHOTO | filters.TEXT, payment_received)],
        },
        fallbacks=[
            CommandHandler("cancel", cancel),
            MessageHandler(filters.Regex("ሰርዝ"), cancel),
        ],
        conversation_timeout=1800,
        per_chat=True,
        per_message=False,
    )