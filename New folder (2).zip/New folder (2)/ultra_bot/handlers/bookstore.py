"""Book store: categories, subscription (300), group (700)."""
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    CallbackQueryHandler, CommandHandler, ContextTypes,
    ConversationHandler, MessageHandler, filters,
)
from config import config
from database import db
from keyboards import (
    bookstore_menu, book_action_inline, admin_book_decision,
    main_menu, cancel_only,
)
from middleware import rate_limited
from texts import t
from validators import sanitize

logger = logging.getLogger(__name__)

PICK_ACTION, BOOK_PAY_UPLOAD = range(100, 102)


def _bookstore_text() -> str:
    return t(
        "bookstore_menu",
        subscription=config.BOOKSTORE_SUBSCRIPTION_PRICE,
        group_price=config.BOOKSTORE_GROUP_PRICE,
    )


async def open_bookstore(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    await update.message.reply_text(
        _bookstore_text(), reply_markup=bookstore_menu(), parse_mode="HTML",
    )
    await update.message.reply_text(
        "👇 ከታች ካሉት ምድቦች አንዱን ይምረጡ፦",
        reply_markup=cancel_only(),
    )
    return PICK_ACTION


async def show_category(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    if not await db.user_has_bookstore_access(update.effective_user.id):
        await q.message.reply_text(
            "🔒 <b>ይህን ምድብ ለማግኘት የመጽሐፍ መደብር አባል መሆን ያስፈልግዎታል።</b>\n\n"
            f"💰 የአባልነት ዋጋ፦ <b>{config.BOOKSTORE_SUBSCRIPTION_PRICE} ብር</b>\n\n"
            "🎁 ለመመዝገብ «🎁 ሙሉ አባልነት» የሚለውን ይጫኑ።",
            parse_mode="HTML",
        )
        return PICK_ACTION
    mapping = {
        "book_story":    config.STORY_BOOKS_LINK,
        "book_academic": config.ACADEMIC_BOOKS_LINK,
        "book_english":  config.ENGLISH_BOOKS_LINK,
    }
    link = mapping.get(q.data)
    if link:
        await q.message.reply_text(
            f"📚 <b>ወደዚህ ቻናል ይግቡ፦</b>\n\n{link}",
            parse_mode="HTML",
        )
    return PICK_ACTION


async def subscription_intro(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    if await db.user_has_bookstore_access(update.effective_user.id):
        await q.message.reply_text(t("already_subscribed"), parse_mode="HTML")
        return PICK_ACTION
    context.user_data["book_order_type"] = "subscription"
    context.user_data["book_amount"] = config.BOOKSTORE_SUBSCRIPTION_PRICE
    await q.message.reply_text(
        t("bookstore_subscription_intro", price=config.BOOKSTORE_SUBSCRIPTION_PRICE),
        reply_markup=book_action_inline(), parse_mode="HTML",
    )
    return PICK_ACTION


async def group_intro(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    if await db.user_has_group_access(update.effective_user.id):
        await q.message.reply_text(t("already_in_group"), parse_mode="HTML")
        return PICK_ACTION
    context.user_data["book_order_type"] = "group"
    context.user_data["book_amount"] = config.BOOKSTORE_GROUP_PRICE
    await q.message.reply_text(
        t("bookstore_group_intro", price=config.BOOKSTORE_GROUP_PRICE),
        reply_markup=book_action_inline(), parse_mode="HTML",
    )
    return PICK_ACTION


async def show_book_payment(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    amount = context.user_data.get("book_amount", config.BOOKSTORE_SUBSCRIPTION_PRICE)
    await q.message.reply_text(
        t(
            "bookstore_pay_instructions",
            amount=amount,
            cbe=config.CBE_ACCOUNT,
            dashen=config.DASHEN_ACCOUNT,
            abyssinia=config.ABYSSINIA_ACCOUNT,
            telebirr=config.TELEBIRR,
            bank_holder=config.BANK_HOLDER_NAME,
        ),
        parse_mode="HTML",
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=t("upload_prompt"),
        reply_markup=cancel_only(), parse_mode="HTML",
    )
    return BOOK_PAY_UPLOAD


@rate_limited
async def book_payment_received(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.text and "ሰርዝ" in update.message.text:
        return await cancel_book(update, context)
    file_id = None
    txid = None
    if update.message.photo:
        file_id = update.message.photo[-1].file_id
    elif update.message.text:
        txid = sanitize(update.message.text, 100)
        if len(txid) < 4:
            await update.message.reply_text(t("not_photo_or_text"), parse_mode="HTML")
            return BOOK_PAY_UPLOAD
    else:
        await update.message.reply_text(t("not_photo_or_text"), parse_mode="HTML")
        return BOOK_PAY_UPLOAD
    user = update.effective_user
    order_type = context.user_data.get("book_order_type", "subscription")
    amount = context.user_data.get("book_amount", config.BOOKSTORE_SUBSCRIPTION_PRICE)
    try:
        order_id = await db.create_book_order(
            user_id=user.id, username=user.username,
            full_name=user.first_name or "", phone="",
            order_type=order_type, category=order_type, amount=amount,
            receipt_file=file_id, transaction_id=txid,
        )
    except Exception as e:
        logger.exception("book order insert failed")
        await update.message.reply_text(
            f"⚠️ ስህተት ተከስቷል።\nእባክዎ /start ይጫኑ።\n{type(e).__name__}",
            reply_markup=main_menu(),
        )
        return ConversationHandler.END
    await db.clear_state(user.id)
    label = "ሙሉ አባልነት" if order_type == "subscription" else "ግሩፕ አባልነት"
    caption = (
        f"📚 <b>አዲስ የመጽሐፍ ትዕዛዝ #{order_id}</b>\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>ተጠቃሚ፦</b> {user.first_name or ''}\n"
        f"🆔 <b>User ID፦</b> <code>{user.id}</code>\n"
        f"📦 <b>ዓይነት፦</b> {label}\n"
        f"💰 <b>መጠን፦</b> {amount} ብር\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
    )
    if txid:
        caption += f"🧾 <b>Transaction ID:</b> <code>{txid}</code>\n"
    if file_id:
        caption += "📷 <b>ደረሰኝ፦</b> ፎቶ ተያይዟል\n"
    for admin_id in config.ADMIN_IDS:
        try:
            if file_id:
                await context.bot.send_photo(
                    chat_id=admin_id, photo=file_id, caption=caption,
                    reply_markup=admin_book_decision(order_id), parse_mode="HTML",
                )
            else:
                await context.bot.send_message(
                    chat_id=admin_id, text=caption,
                    reply_markup=admin_book_decision(order_id), parse_mode="HTML",
                )
        except Exception as e:
            logger.error("book admin notify %s: %s", admin_id, e)
    await update.message.reply_text(
        t("book_order_done", help_phone=config.HELP_CENTER_PHONE),
        reply_markup=main_menu(), parse_mode="HTML",
    )
    return ConversationHandler.END


async def cancel_book(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    await update.message.reply_text(t("cancelled"), reply_markup=main_menu())
    return ConversationHandler.END


def build_book_conversation() -> ConversationHandler:
    return ConversationHandler(
        entry_points=[
            CommandHandler("bookstore", open_bookstore),
            MessageHandler(filters.Regex("^📚"), open_bookstore),
        ],
        states={
            PICK_ACTION: [
                CallbackQueryHandler(subscription_intro, pattern="^book_subscription$"),
                CallbackQueryHandler(group_intro, pattern="^book_group$"),
                CallbackQueryHandler(show_book_payment, pattern="^book_pay_confirm$"),
                CallbackQueryHandler(show_category, pattern="^book_(story|academic|english)$"),
            ],
            BOOK_PAY_UPLOAD: [
                MessageHandler(filters.PHOTO | filters.TEXT, book_payment_received),
            ],
        },
        fallbacks=[
            CommandHandler("cancel", cancel_book),
            MessageHandler(filters.Regex("ሰርዝ"), cancel_book),
        ],
        conversation_timeout=1800,
        per_chat=True,
        per_message=False,
    )