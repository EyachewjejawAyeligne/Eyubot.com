from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)


def main_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        [
            ["🚀 ምዝገባ ጀምር", "📚 የመጽሐፍ መደብር"],
            ["ℹ️ ስለ እኛ", "📊 ሁኔታዬ"],
            ["❓ እርዳታ", "❌ ሰርዝ"],
        ],
        resize_keyboard=True,
    )


def cancel_only() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup([["❌ ምዝገባ ሰርዝ"]], resize_keyboard=True)


def phone_request() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        [
            [KeyboardButton("📱 ስልክ ቁጥሬን አጋራ", request_contact=True)],
            ["❌ ምዝገባ ሰርዝ"],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def grade_inline(student_num: int) -> InlineKeyboardMarkup:
    grades = [
        ("👶 KG", "kg"),
        ("1️⃣ 1ኛ", "1"), ("2️⃣ 2ኛ", "2"),
        ("3️⃣ 3ኛ", "3"), ("4️⃣ 4ኛ", "4"),
        ("5️⃣ 5ኛ", "5"), ("6️⃣ 6ኛ", "6"),
        ("7️⃣ 7ኛ", "7"), ("8️⃣ 8ኛ", "8"),
        ("9️⃣ 9ኛ", "9"), ("🔟 10ኛ", "10"),
        ("1️⃣1️⃣ 11ኛ", "11"), ("1️⃣2️⃣ 12ኛ", "12"),
        ("🌟 ልዩ ፍላጎት", "special"),
    ]
    rows = []
    for i in range(0, len(grades), 2):
        pair = grades[i:i + 2]
        rows.append([
            InlineKeyboardButton(label, callback_data=f"grade_{student_num}_{code}")
            for label, code in pair
        ])
    return InlineKeyboardMarkup(rows)


def hours_per_day_inline() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⏱ 1 ሰዓት / ቀን", callback_data="hours_1")],
        [InlineKeyboardButton("⏱ 1 ሰዓት 30 ደቂቃ / ቀን", callback_data="hours_1.5")],
        [InlineKeyboardButton("⏱ 2 ሰዓት / ቀን", callback_data="hours_2")],
    ])


def schedule_inline() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🌅 ቅዳሜ እና እሁድ (ጠዋት)", callback_data="sched_weekend_morning")],
        [InlineKeyboardButton("🌇 ቅዳሜ እና እሁድ (ከሰዓት)", callback_data="sched_weekend_afternoon")],
        [InlineKeyboardButton("🌙 ከሰኞ - አርብ (ከሰዓት በኋላ)", callback_data="sched_weekday")],
    ])


def confirm_price_inline() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ እቀበላለሁ", callback_data="price_accept"),
            InlineKeyboardButton("❌ አልቀበልም", callback_data="price_decline"),
        ]
    ])


def payment_plan_inline() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📅 በየቀኑ (Daily)", callback_data="plan_daily")],
        [InlineKeyboardButton("📅 በየሳምንቱ (Weekly)", callback_data="plan_weekly")],
        [InlineKeyboardButton("📅 በየወሩ (Monthly)", callback_data="plan_monthly")],
    ])


def channel_group_inline(channel: str, group: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 የማስታወቂያ ቻናል", url=channel)],
        [InlineKeyboardButton("💬 የውይይት ግሩፕ", url=group)],
    ])


# ───── BOOK STORE ─────
def bookstore_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📖 የልጆች ተረት መጽሐፍት", callback_data="book_story")],
        [InlineKeyboardButton("📚 የትምህርት መጽሐፍት (ከመልስ)", callback_data="book_academic")],
        [InlineKeyboardButton("🔤 English Language Books", callback_data="book_english")],
        [InlineKeyboardButton("🎁 ሙሉ አባልነት — 300 ብር", callback_data="book_subscription")],
        [InlineKeyboardButton("💬 ግሩፕ አባልነት — 700 ብር", callback_data="book_group")],
    ])


def book_action_inline() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ እከፍላለሁ", callback_data="book_pay_confirm")],
        [InlineKeyboardButton("↩️ ተመለስ", callback_data="book_back")],
    ])


def admin_book_decision(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ Approve", callback_data=f"bapprove_{order_id}"),
        InlineKeyboardButton("❌ Reject", callback_data=f"breject_{order_id}"),
    ]])


def admin_book_reject_reasons(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💰 ክፍያ አልተረጋገጠም", callback_data=f"breason_{order_id}_no_payment")],
        [InlineKeyboardButton("🚫 ሌላ ምክንያት", callback_data=f"breason_{order_id}_other")],
        [InlineKeyboardButton("↩️ ተመለስ", callback_data=f"bback_{order_id}")],
    ])


def admin_decision(user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ አጽድቅ", callback_data=f"approve_{user_id}"),
        InlineKeyboardButton("❌ ውድቅ አድርግ", callback_data=f"reject_{user_id}"),
    ]])


def admin_reject_reasons(user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⏰ ነፃ ጊዜ የለም", callback_data=f"reason_{user_id}_no_time")],
        [InlineKeyboardButton("💰 ክፍያ አልተረጋገጠም", callback_data=f"reason_{user_id}_no_payment")],
        [InlineKeyboardButton("📚 ትምህርት አልተገኘም", callback_data=f"reason_{user_id}_no_subject")],
        [InlineKeyboardButton("📵 ስልክ አልተገኘም", callback_data=f"reason_{user_id}_no_contact")],
        [InlineKeyboardButton("🚫 ሌላ ምክንያት", callback_data=f"reason_{user_id}_other")],
        [InlineKeyboardButton("↩️ ተመለስ", callback_data=f"back_{user_id}")],
    ])